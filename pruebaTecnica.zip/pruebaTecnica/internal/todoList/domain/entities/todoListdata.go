package entities

type TodoListRequest struct {
	Id          int
	Name        string
	Description string
	Status      string
	DateIni     string
	DateEnd     string
	Priority    string
}
