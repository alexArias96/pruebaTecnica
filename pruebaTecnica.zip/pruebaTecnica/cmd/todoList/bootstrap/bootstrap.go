package bootstrap

import (
	"log"
	"net/http"
	"pruebaTecnica/internal/todoList/domain/entities"
	"text/template"
)

var templates = template.Must(template.ParseGlob("templates/*"))

func Run() {
	http.HandleFunc("/", Index)
	log.Println("Run server")
	http.ListenAndServe(":8080", nil)
}

func Index(w http.ResponseWriter, r *http.Request) {
	name := r.FormValue("name")
	desc := r.FormValue("desc")
	status := r.FormValue("status")
	dateInit := r.FormValue("dateinit")
	dateEnd := r.FormValue("dateend")
	priority := r.FormValue("priority")

	data := GetFromData(name, desc, status, dateInit, dateEnd, priority)

	templates.ExecuteTemplate(w, "index", data)
}

func GetFromData(a string, b string, c string, d string, e string, f string) *entities.TodoListRequest {

	return &entities.TodoListRequest{
		Id:          0,
		Name:        a,
		Description: b,
		Status:      c,
		DateIni:     d,
		DateEnd:     e,
		Priority:    f,
	}
}
