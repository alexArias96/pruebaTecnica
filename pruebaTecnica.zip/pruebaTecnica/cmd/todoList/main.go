package main

import (
	"log"
	"net/http"
)

func main() {
	http.HandleFunc("/", nil)
	log.Println("Run server...")
}
